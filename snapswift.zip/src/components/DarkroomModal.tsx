import React, { useEffect, useState } from 'react';
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Download,
  Heart,
  RotateCcw,
  Share2,
  Sliders,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import {
  CapturedFrame,
  DarkroomAdjustments,
  FilmStockProfile,
  FrameStyleOption,
} from '../types/camera';
import { FILM_STOCKS } from '../data/presets';
import {
  renderDarkroomExport,
  shareOrDownloadPhoto,
  soundEngine,
  triggerDirectDownload,
} from '../utils/soundAndRender';

interface DarkroomModalProps {
  frame: CapturedFrame;
  allFrames: CapturedFrame[];
  muted: boolean;
  onClose: () => void;
  onSelectFrame: (frame: CapturedFrame) => void;
  onUpdateFrame: (updated: CapturedFrame) => void;
  onDeleteFrame: (id: string) => void;
  onToggleFavorite: (id: string) => void;
}

export const DarkroomModal: React.FC<DarkroomModalProps> = ({
  frame,
  allFrames,
  muted,
  onClose,
  onSelectFrame,
  onUpdateFrame,
  onDeleteFrame,
  onToggleFavorite,
}) => {
  const [adjustments, setAdjustments] = useState<DarkroomAdjustments>(frame.adjustments);
  const [previewUrl, setPreviewUrl] = useState<string>(frame.renderedDataUrl);
  const [isRendering, setIsRendering] = useState(false);
  const [compareRaw, setCompareRaw] = useState(false);
  const [downloadToast, setDownloadToast] = useState<string | null>(null);

  const currentIndex = allFrames.findIndex((f) => f.id === frame.id);
  const hasPrev = currentIndex > 0;
  const hasNext = currentIndex >= 0 && currentIndex < allFrames.length - 1;

  // Sync local adjustments when active frame changes
  useEffect(() => {
    setAdjustments(frame.adjustments);
    setPreviewUrl(frame.renderedDataUrl);
  }, [frame.id, frame.adjustments, frame.renderedDataUrl]);

  // Re-render non-destructive darkroom output whenever adjustments change
  useEffect(() => {
    if (frame.mediaType === 'video') return;
    let cancelled = false;
    setIsRendering(true);

    const activeFilm: FilmStockProfile =
      FILM_STOCKS.find((f) => f.id === adjustments.filmStockId) || FILM_STOCKS[0];

    const timer = setTimeout(async () => {
      const resultUrl = await renderDarkroomExport(
        frame.sourceDataUrl,
        adjustments,
        activeFilm,
        frame.dateStampText
      );
      if (!cancelled) {
        setPreviewUrl(resultUrl);
        setIsRendering(false);
      }
    }, 35);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [adjustments, frame.sourceDataUrl, frame.dateStampText, frame.mediaType]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft' && hasPrev) {
        onSelectFrame(allFrames[currentIndex - 1]);
      }
      if (e.key === 'ArrowRight' && hasNext) {
        onSelectFrame(allFrames[currentIndex + 1]);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, hasPrev, hasNext, allFrames, onClose, onSelectFrame]);

  const handleApplyPreset = (stock: FilmStockProfile) => {
    soundEngine.playDialDetent(muted);
    const nextAdj: DarkroomAdjustments = {
      ...adjustments,
      filmStockId: stock.id,
      contrast: stock.contrast,
      saturation: stock.saturation,
      warmth: stock.warmth,
      grain: stock.grain,
      vignette: stock.vignette,
      fade: stock.fade,
    };
    setAdjustments(nextAdj);
  };

  const handleReset = () => {
    soundEngine.playDialDetent(muted);
    const neutral = FILM_STOCKS[0];
    setAdjustments({
      exposure: 0,
      contrast: neutral.contrast,
      saturation: neutral.saturation,
      warmth: neutral.warmth,
      grain: neutral.grain,
      vignette: neutral.vignette,
      fade: neutral.fade,
      filmStockId: neutral.id,
      frameStyle: 'none',
      dateStamp: false,
    });
  };

  const handleSaveAdjustments = () => {
    soundEngine.playDialDetent(muted);
    const activeFilm =
      FILM_STOCKS.find((f) => f.id === adjustments.filmStockId) || FILM_STOCKS[0];
    onUpdateFrame({
      ...frame,
      renderedDataUrl: previewUrl,
      adjustments,
      exif: {
        ...frame.exif,
        filmStockName: activeFilm.name,
      },
    });
    setDownloadToast('Darkroom grade saved to Contact Sheet');
    setTimeout(() => setDownloadToast(null), 2400);
  };

  const handleDirectDownload = () => {
    soundEngine.playShutterClick(muted);
    const cleanTitle = frame.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    if (frame.mediaType === 'video' && frame.videoBlobUrl) {
      triggerDirectDownload(frame.videoBlobUrl, `vespera-${cleanTitle}.webm`);
    } else {
      triggerDirectDownload(previewUrl, `vespera-${cleanTitle}.jpg`);
    }
    setDownloadToast('Downloaded directly to your device');
    setTimeout(() => setDownloadToast(null), 2600);
  };

  const handleMobileShare = async () => {
    soundEngine.playDialDetent(muted);
    const cleanTitle = frame.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    await shareOrDownloadPhoto(previewUrl, `vespera-${cleanTitle}.jpg`, frame.title);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col lg:flex-row bg-[#08080A]/95 backdrop-blur-xl text-[#F4F4F0] overflow-y-auto lg:overflow-hidden">
      {/* Left / Main Optical Lightbox Stage */}
      <div className="relative flex-1 flex flex-col justify-between p-4 sm:p-6 min-h-[56vh] lg:min-h-0 select-none">
        {/* Top Lightbox Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 z-10 border-b border-white/10 pb-3">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="flex items-center gap-2 px-3 py-1.5 rounded bg-[#141417] hover:bg-[#1E1E24] border border-white/10 text-xs font-mono-tabular uppercase tracking-wider transition cursor-pointer"
            >
              <X className="w-4 h-4 text-[#A1A1AA]" />
              <span>Return to Viewfinder</span>
            </button>
            <div>
              <h2 className="text-sm sm:text-base font-medium tracking-tight text-[#F4F4F0]">
                {frame.title}
              </h2>
              <p className="text-[11px] font-mono-tabular text-[#A1A1AA]">
                {frame.timestamp} · {frame.exif.focalLength} · {frame.exif.aperture} ·{' '}
                {frame.exif.shutterSpeed} · ISO {frame.exif.iso}
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            {frame.mediaType === 'photo' && (
              <button
                onMouseDown={() => setCompareRaw(true)}
                onMouseUp={() => setCompareRaw(false)}
                onMouseLeave={() => setCompareRaw(false)}
                onTouchStart={() => setCompareRaw(true)}
                onTouchEnd={() => setCompareRaw(false)}
                className={`px-3 py-1.5 rounded text-xs font-mono-tabular uppercase tracking-wider border transition cursor-pointer ${
                  compareRaw
                    ? 'bg-[#F2B705] text-[#08080A] border-[#F2B705] font-semibold'
                    : 'bg-[#141417] text-[#A1A1AA] border-white/10 hover:text-white'
                }`}
              >
                {compareRaw ? 'Showing Optical RAW' : 'Hold: Compare RAW'}
              </button>
            )}

            <button
              onClick={() => onToggleFavorite(frame.id)}
              className={`p-2 rounded border transition cursor-pointer ${
                frame.favorite
                  ? 'bg-[#E11D48]/15 border-[#E11D48]/50 text-[#E11D48]'
                  : 'bg-[#141417] border-white/10 text-[#A1A1AA] hover:text-white'
              }`}
              title="Favorite Frame"
            >
              <Heart className={`w-4 h-4 ${frame.favorite ? 'fill-current' : ''}`} />
            </button>

            <button
              onClick={() => {
                onDeleteFrame(frame.id);
                onClose();
              }}
              className="p-2 rounded bg-[#141417] hover:bg-[#E11D48]/20 border border-white/10 hover:border-[#E11D48]/40 text-[#A1A1AA] hover:text-[#E11D48] transition cursor-pointer"
              title="Delete Frame"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Center Image / Video Canvas */}
        <div className="relative flex-1 flex items-center justify-center my-4 overflow-hidden">
          {hasPrev && (
            <button
              onClick={() => onSelectFrame(allFrames[currentIndex - 1])}
              className="absolute left-2 z-20 p-2.5 rounded-full bg-[#141417]/90 hover:bg-[#1E1E24] border border-white/15 text-[#F4F4F0] transition cursor-pointer"
              title="Previous Frame"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}

          {frame.mediaType === 'video' && frame.videoBlobUrl ? (
            <video
              src={frame.videoBlobUrl}
              controls
              autoPlay
              loop
              className="max-h-[65vh] max-w-full rounded border border-white/10 shadow-2xl"
            />
          ) : (
            <div className="relative flex items-center justify-center max-h-[66vh] max-w-full">
              <img
                src={compareRaw ? frame.sourceDataUrl : previewUrl}
                alt={frame.title}
                className="max-h-[64vh] max-w-full object-contain rounded shadow-[0_24px_60px_rgba(0,0,0,0.85)] transition-opacity duration-150"
              />
              {isRendering && (
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded bg-[#08080A]/80 border border-white/10 text-[10px] font-mono-tabular text-[#F2B705] uppercase tracking-wider">
                  Developing...
                </div>
              )}
            </div>
          )}

          {hasNext && (
            <button
              onClick={() => onSelectFrame(allFrames[currentIndex + 1])}
              className="absolute right-2 z-20 p-2.5 rounded-full bg-[#141417]/90 hover:bg-[#1E1E24] border border-white/15 text-[#F4F4F0] transition cursor-pointer"
              title="Next Frame"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Bottom EXIF Telemetry Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-3 text-xs font-mono-tabular text-[#A1A1AA]">
          <div className="flex flex-wrap items-center gap-4">
            <span>
              BODY: <strong className="text-[#F4F4F0]">{frame.exif.cameraModel}</strong>
            </span>
            <span>
              OPTIC: <strong className="text-[#F4F4F0]">{frame.exif.lens}</strong>
            </span>
            <span>
              STOCK: <strong className="text-[#F2B705]">{frame.exif.filmStockName}</strong>
            </span>
            <span>
              WB: <strong className="text-[#F4F4F0]">{frame.exif.kelvin}K</strong>
            </span>
          </div>
          <div>
            FRAME {currentIndex + 1} OF {allFrames.length}
          </div>
        </div>
      </div>

      {/* Right Darkroom Grading & Export Deck */}
      <div className="w-full lg:w-[390px] bg-[#101013] border-t lg:border-t-0 lg:border-l border-white/10 flex flex-col justify-between p-5 overflow-y-auto">
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#F2B705]" />
              <h3 className="text-xs font-mono-tabular uppercase tracking-widest text-[#F4F4F0]">
                Optical Darkroom Studio
              </h3>
            </div>
            <button
              onClick={handleReset}
              className="flex items-center gap-1 text-[11px] font-mono-tabular text-[#A1A1AA] hover:text-[#F4F4F0] transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>

          {/* Direct Download & Phone Save Primary Callouts */}
          <div className="space-y-2.5 bg-[#141418] p-3.5 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono-tabular uppercase tracking-wider text-[#F2B705]">
                Instant Device Export
              </span>
              <span className="text-[11px] font-mono-tabular text-[#10B981]">
                High-Res JPEG
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={handleDirectDownload}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded bg-[#F4F4F0] hover:bg-white text-[#08080A] font-semibold text-xs tracking-wide transition shadow cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Photo</span>
              </button>
              <button
                onClick={handleMobileShare}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded bg-[#1E1E24] hover:bg-[#27272F] text-[#F4F4F0] border border-white/15 font-medium text-xs tracking-wide transition cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-[#F2B705]" />
                <span>Save to Phone</span>
              </button>
            </div>
            {downloadToast && (
              <div className="flex items-center gap-1.5 text-[11px] font-mono-tabular text-[#10B981] pt-1">
                <Check className="w-3.5 h-3.5" />
                <span>{downloadToast}</span>
              </div>
            )}
          </div>

          {/* Film Emulation Stock Selector */}
          <div className="space-y-2.5">
            <label className="block text-[11px] font-mono-tabular uppercase tracking-wider text-[#A1A1AA]">
              Analog Film Emulation
            </label>
            <div className="grid grid-cols-2 gap-2">
              {FILM_STOCKS.map((stock) => {
                const active = adjustments.filmStockId === stock.id;
                return (
                  <button
                    key={stock.id}
                    onClick={() => handleApplyPreset(stock)}
                    className={`flex flex-col items-start p-2.5 rounded border text-left transition cursor-pointer ${
                      active
                        ? 'bg-[#1C1C22] border-[#F2B705] text-[#F4F4F0]'
                        : 'bg-[#141417] border-white/10 text-[#A1A1AA] hover:border-white/25 hover:text-[#F4F4F0]'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-[10px] font-mono-tabular uppercase tracking-wider text-[#F2B705]">
                        {stock.code}
                      </span>
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: stock.accentHex }}
                      />
                    </div>
                    <span className="text-xs font-medium mt-0.5 line-clamp-1">
                      {stock.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Precision Grading Sliders */}
          <div className="space-y-4">
            <label className="block text-[11px] font-mono-tabular uppercase tracking-wider text-[#A1A1AA]">
              Color & Silver Halide Curve
            </label>

            {/* Exposure */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono-tabular">
                <span className="text-[#A1A1AA]">EXPOSURE BIAS</span>
                <span className="text-[#F4F4F0]">
                  {adjustments.exposure >= 0 ? `+${adjustments.exposure.toFixed(1)}` : adjustments.exposure.toFixed(1)} EV
                </span>
              </div>
              <input
                type="range"
                min="-2"
                max="2"
                step="0.1"
                value={adjustments.exposure}
                onChange={(e) =>
                  setAdjustments({ ...adjustments, exposure: parseFloat(e.target.value) })
                }
                className="optical-slider"
              />
            </div>

            {/* Contrast */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono-tabular">
                <span className="text-[#A1A1AA]">MICRO CONTRAST</span>
                <span className="text-[#F4F4F0]">
                  {adjustments.contrast >= 0 ? `+${adjustments.contrast}` : adjustments.contrast}
                </span>
              </div>
              <input
                type="range"
                min="-40"
                max="50"
                step="1"
                value={adjustments.contrast}
                onChange={(e) =>
                  setAdjustments({ ...adjustments, contrast: parseInt(e.target.value, 10) })
                }
                className="optical-slider"
              />
            </div>

            {/* Saturation */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono-tabular">
                <span className="text-[#A1A1AA]">COLOR DENSITY</span>
                <span className="text-[#F4F4F0]">{adjustments.saturation}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="180"
                step="2"
                value={adjustments.saturation}
                onChange={(e) =>
                  setAdjustments({ ...adjustments, saturation: parseInt(e.target.value, 10) })
                }
                className="optical-slider"
              />
            </div>

            {/* Warmth */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono-tabular">
                <span className="text-[#A1A1AA]">KELVIN WARMTH</span>
                <span className="text-[#F4F4F0]">
                  {adjustments.warmth >= 0 ? `+${adjustments.warmth}` : adjustments.warmth}
                </span>
              </div>
              <input
                type="range"
                min="-45"
                max="45"
                step="1"
                value={adjustments.warmth}
                onChange={(e) =>
                  setAdjustments({ ...adjustments, warmth: parseInt(e.target.value, 10) })
                }
                className="optical-slider"
              />
            </div>

            {/* Silver Grain */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono-tabular">
                <span className="text-[#A1A1AA]">SILVER HALIDE GRAIN</span>
                <span className="text-[#F4F4F0]">{adjustments.grain}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="85"
                step="1"
                value={adjustments.grain}
                onChange={(e) =>
                  setAdjustments({ ...adjustments, grain: parseInt(e.target.value, 10) })
                }
                className="optical-slider"
              />
            </div>

            {/* Lens Vignette */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono-tabular">
                <span className="text-[#A1A1AA]">OPTICAL VIGNETTE</span>
                <span className="text-[#F4F4F0]">{adjustments.vignette}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="80"
                step="1"
                value={adjustments.vignette}
                onChange={(e) =>
                  setAdjustments({ ...adjustments, vignette: parseInt(e.target.value, 10) })
                }
                className="optical-slider"
              />
            </div>
          </div>

          {/* Exhibition Frame & Quartz Date Stamp */}
          <div className="space-y-2.5">
            <label className="block text-[11px] font-mono-tabular uppercase tracking-wider text-[#A1A1AA]">
              Exhibition Border & Quartz Stamp
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(
                [
                  { id: 'none', label: 'Borderless' },
                  { id: 'museum', label: 'Museum' },
                  { id: 'film35', label: '35mm Film' },
                  { id: 'instant', label: 'Instant' },
                ] as Array<{ id: FrameStyleOption; label: string }>
              ).map((item) => (
                <button
                  key={item.id}
                  onClick={() => setAdjustments({ ...adjustments, frameStyle: item.id })}
                  className={`py-2 px-2 rounded border text-[11px] font-mono-tabular transition cursor-pointer ${
                    adjustments.frameStyle === item.id
                      ? 'bg-[#F2B705] text-[#08080A] border-[#F2B705] font-semibold'
                      : 'bg-[#141417] text-[#A1A1AA] border-white/10 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <button
              onClick={() =>
                setAdjustments({ ...adjustments, dateStamp: !adjustments.dateStamp })
              }
              className={`w-full flex items-center justify-between px-3 py-2 rounded border text-xs font-mono-tabular transition cursor-pointer ${
                adjustments.dateStamp
                  ? 'bg-[#1C1C22] border-[#F2B705]/60 text-[#F2B705]'
                  : 'bg-[#141417] border-white/10 text-[#A1A1AA]'
              }`}
            >
              <span>QUARTZ DATE BURN-IN (&apos;26 09 26)</span>
              <span>{adjustments.dateStamp ? 'ON' : 'OFF'}</span>
            </button>
          </div>
        </div>

        {/* Commit Darkroom Grade Button */}
        <div className="pt-5 mt-5 border-t border-white/10">
          <button
            onClick={handleSaveAdjustments}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded bg-[#1E1E26] hover:bg-[#282832] border border-white/15 text-xs font-mono-tabular uppercase tracking-wider text-[#F4F4F0] transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#F2B705]" />
            <span>Commit Grade to Contact Sheet</span>
          </button>
        </div>
      </div>
    </div>
  );
};
