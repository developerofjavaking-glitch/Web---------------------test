export type AspectRatioOption = '3:2' | '16:9' | '4:3' | '1:1';
export type GridOverlayOption = 'thirds' | 'golden' | 'crosshair' | 'none';
export type CaptureMode = 'single' | 'burst' | 'video';
export type TimerOption = 0 | 3 | 10;
export type FrameStyleOption = 'none' | 'museum' | 'film35' | 'instant';

export interface FilmStockProfile {
  id: string;
  name: string;
  code: string;
  category: 'color' | 'monochrome' | 'instant';
  isoNominal: number;
  description: string;
  // Grading parameters
  contrast: number;       // -40 to +40
  saturation: number;     // 0 to 180 (0 = B&W, 100 = normal)
  warmth: number;         // -50 to +50 (Kelvin shift)
  tint: number;           // -30 to +30 (green/magenta)
  grain: number;          // 0 to 100
  vignette: number;       // 0 to 100
  halation: number;       // 0 to 100 (warm highlight glow)
  fade: number;           // 0 to 40 (lifted blacks)
  accentHex: string;
}

export interface ExposureSettings {
  aperture: number;       // e.g. 1.4, 2.0, 2.8, 4.0, 5.6, 8.0, 11, 16
  shutterSpeed: string;   // e.g. '1/4000', '1/1000', '1/250', '1/60', '1/15', '1/4'
  iso: number;            // 100, 200, 400, 800, 1600, 3200, 6400
  evCompensation: number; // -3.0 to +3.0
  kelvin: number;         // 2800 to 8500 (5500 neutral)
  focusDistance: number;  // 0.3m to 10.0m (controls bokeh on non-focused areas or manual blur)
  autoFocus: boolean;
  focalLengthMm: 28 | 35 | 50 | 85; // Optical crop/zoom equivalent
}

export interface AssistOverlays {
  grid: GridOverlayOption;
  showHistogram: boolean;
  showHorizon: boolean;
  focusPeaking: boolean;
  zebraStripes: boolean;
  dateStamp: boolean;
  mirrorFrontCamera: boolean;
}

export interface DarkroomAdjustments {
  exposure: number;       // -2.0 to +2.0
  contrast: number;       // -50 to +50
  saturation: number;     // 0 to 200
  warmth: number;         // -50 to +50
  grain: number;          // 0 to 100
  vignette: number;       // 0 to 100
  fade: number;           // 0 to 40
  filmStockId: string;
  frameStyle: FrameStyleOption;
  dateStamp: boolean;
}

export interface CapturedFrame {
  id: string;
  title: string;
  timestamp: string;
  dateStampText: string;
  mediaType: 'photo' | 'video';
  sourceDataUrl: string;  // Raw ungraded base image or video poster
  renderedDataUrl: string;// Graded preview image
  videoBlobUrl?: string;
  aspectRatio: AspectRatioOption;
  favorite: boolean;
  exif: {
    cameraModel: string;
    lens: string;
    focalLength: string;
    aperture: string;
    shutterSpeed: string;
    iso: number;
    ev: string;
    kelvin: number;
    filmStockName: string;
    dimensions: string;
  };
  adjustments: DarkroomAdjustments;
}

export interface SimulatedScene {
  id: string;
  title: string;
  location: string;
  imageUrl: string;
  optimalFocusMeters: number;
  baseKelvin: number;
  defaultFilmId: string;
  exifPreset: {
    aperture: number;
    shutterSpeed: string;
    iso: number;
    focalLengthMm: 28 | 35 | 50 | 85;
  };
}
