/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Aperture,
  Camera,
  Check,
  Compass,
  Download,
  Eye,
  Film,
  FlipHorizontal,
  Grid,
  Heart,
  Image as ImageIcon,
  Layers,
  Maximize2,
  RefreshCw,
  Share2,
  Sliders,
  Smartphone,
  Sparkles,
  Sun,
  Timer,
  Trash2,
  Upload,
  Video,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import {
  AspectRatioOption,
  AssistOverlays,
  CapturedFrame,
  CaptureMode,
  ExposureSettings,
  FilmStockProfile,
  GridOverlayOption,
  TimerOption,
} from './types/camera';
import {
  APERTURE_STOPS,
  FILM_STOCKS,
  FOCAL_LENGTHS,
  INITIAL_CAPTURED_FRAMES,
  ISO_STOPS,
  SHUTTER_SPEEDS,
  SIMULATED_SCENES,
} from './data/presets';
import {
  computeHistogram,
  getAspectRatioDimensions,
  HistogramData,
  renderOpticalFrame,
  shareOrDownloadPhoto,
  soundEngine,
  triggerDirectDownload,
} from './utils/soundAndRender';
import { DarkroomModal } from './components/DarkroomModal';

export default function App() {
  // Camera Hardware & Source State
  const [sourceMode, setSourceMode] = useState<'webcam' | 'simulator'>('webcam');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [activeSceneIndex, setActiveSceneIndex] = useState<number>(0);

  // Direct Download to Phone / PC State (Enabled by default per user request!)
  const [autoDownloadOnCapture, setAutoDownloadOnCapture] = useState<boolean>(true);
  const [screenFlashEnabled, setScreenFlashEnabled] = useState<boolean>(false);
  const [isScreenFlashing, setIsScreenFlashing] = useState<boolean>(false);
  const [captureToast, setCaptureToast] = useState<{
    message: string;
    frame: CapturedFrame;
  } | null>(null);

  // Optical & Exposure Settings
  const [exposure, setExposure] = useState<ExposureSettings>({
    aperture: 2.0,
    shutterSpeed: '1/250',
    iso: 400,
    evCompensation: 0.0,
    kelvin: 5500,
    focusDistance: 2.2,
    autoFocus: true,
    focalLengthMm: 35,
  });

  // Active Film Emulation Profile
  const [selectedFilmId, setSelectedFilmId] = useState<string>('portra-400');
  const activeFilm: FilmStockProfile =
    FILM_STOCKS.find((f) => f.id === selectedFilmId) || FILM_STOCKS[0];

  // Framing & Viewfinder Assist Overlays
  const [aspectRatio, setAspectRatio] = useState<AspectRatioOption>('3:2');
  const [assist, setAssist] = useState<AssistOverlays>({
    grid: 'thirds',
    showHistogram: true,
    showHorizon: true,
    focusPeaking: false,
    zebraStripes: false,
    dateStamp: true,
    mirrorFrontCamera: true,
  });

  // Drive, Timer, Audio & Recording State
  const [captureMode, setCaptureMode] = useState<CaptureMode>('single');
  const [timerSeconds, setTimerSeconds] = useState<TimerOption>(0);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [muted, setMuted] = useState<boolean>(false);
  const [shutterCurtainClosed, setShutterCurtainClosed] = useState<boolean>(false);
  const [isRecordingVideo, setIsRecordingVideo] = useState<boolean>(false);
  const [recordingDuration, setRecordingDuration] = useState<number>(0);

  // Tap-to-Focus Reticle on Viewfinder
  const [focusPoint, setFocusPoint] = useState<{ x: number; y: number; active: boolean }>({
    x: 50,
    y: 50,
    active: false,
  });

  // Live Histogram Telemetry
  const [histogram, setHistogram] = useState<HistogramData>({
    luma: new Array(32).fill(15),
    r: new Array(32).fill(10),
    g: new Array(32).fill(10),
    b: new Array(32).fill(10),
    overexposedPct: 0,
    underexposedPct: 0,
  });

  // Captured Roll & Darkroom Modal
  const [frames, setFrames] = useState<CapturedFrame[]>(INITIAL_CAPTURED_FRAMES);
  const [activeDarkroomFrame, setActiveDarkroomFrame] = useState<CapturedFrame | null>(null);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState<boolean>(false);
  const [mobileControlTab, setMobileControlTab] = useState<'optics' | 'film' | 'assist'>('optics');

  // Refs for Optical Pipeline
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const simImageRef = useRef<HTMLImageElement | null>(null);
  const viewfinderCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const contactSheetRef = useRef<HTMLDivElement | null>(null);

  const currentSimulatedScene = SIMULATED_SCENES[activeSceneIndex];

  // Preload simulator image whenever scene changes
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = currentSimulatedScene.imageUrl;
    img.onload = () => {
      simImageRef.current = img;
    };
  }, [currentSimulatedScene]);

  // Start / Switch Live Hardware Camera (Mobile Front/Rear or PC Webcam)
  const startWebcam = useCallback(
    async (preferredFacing?: 'user' | 'environment') => {
      const targetFacing = preferredFacing || facingMode;
      setCameraError(null);

      // Stop any existing tracks first
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((t) => t.stop());
        mediaStreamRef.current = null;
      }

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Browser camera API unavailable — running Optical Studio Simulator.');
        setCameraActive(false);
        setSourceMode('simulator');
        return;
      }

      try {
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: { ideal: targetFacing },
              width: { ideal: 1920 },
              height: { ideal: 1080 },
            },
            audio: false,
          });
        } catch {
          // Fallback to any available video input on PC
          stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: false,
          });
        }

        mediaStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }
        setCameraActive(true);
        setSourceMode('webcam');
        // Mirror only when front selfie camera is active
        setAssist((prev) => ({
          ...prev,
          mirrorFrontCamera: targetFacing === 'user',
        }));
      } catch {
        setCameraError(
          'Camera permission denied or no camera detected — switched to Optical Scene Simulator.'
        );
        setCameraActive(false);
        setSourceMode('simulator');
      }
    },
    [facingMode]
  );

  // Attempt hardware camera connection on mount
  useEffect(() => {
    startWebcam('environment');
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  // Flip between Mobile Front & Rear Camera
  const handleFlipCamera = () => {
    soundEngine.playDialDetent(muted);
    const nextFacing = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextFacing);
    startWebcam(nextFacing);
  };

  // Real-time 60fps Canvas Viewfinder & Histogram Loop
  useEffect(() => {
    let animId = 0;
    let frameTick = 0;

    const renderLoop = () => {
      const canvas = viewfinderCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          const { width: targetW, height: targetH } = getAspectRatioDimensions(aspectRatio, 1280);
          if (canvas.width !== targetW || canvas.height !== targetH) {
            canvas.width = targetW;
            canvas.height = targetH;
          }

          if (
            sourceMode === 'webcam' &&
            cameraActive &&
            videoRef.current &&
            videoRef.current.readyState >= 2
          ) {
            renderOpticalFrame({
              ctx,
              source: videoRef.current,
              sourceWidth: videoRef.current.videoWidth || 1280,
              sourceHeight: videoRef.current.videoHeight || 720,
              targetWidth: targetW,
              targetHeight: targetH,
              exposure,
              film: activeFilm,
              assist,
              optimalSceneFocusMeters: 1.8,
              isLiveCamera: true,
              includeOverlaysInRender: true,
            });
          } else if (simImageRef.current) {
            renderOpticalFrame({
              ctx,
              source: simImageRef.current,
              sourceWidth: simImageRef.current.naturalWidth || 1280,
              sourceHeight: simImageRef.current.naturalHeight || 720,
              targetWidth: targetW,
              targetHeight: targetH,
              exposure,
              film: activeFilm,
              assist,
              optimalSceneFocusMeters: currentSimulatedScene.optimalFocusMeters,
              isLiveCamera: false,
              includeOverlaysInRender: true,
            });
          }

          // Update live RGB/Luma histogram every 6 frames (~10Hz)
          frameTick++;
          if (assist.showHistogram && frameTick % 6 === 0) {
            setHistogram(computeHistogram(ctx, targetW, targetH));
          }
        }
      }
      animId = requestAnimationFrame(renderLoop);
    };

    animId = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(animId);
  }, [
    aspectRatio,
    sourceMode,
    cameraActive,
    exposure,
    activeFilm,
    assist,
    currentSimulatedScene,
  ]);

  // Execute High-Resolution Capture & Instant Direct Download to Phone / PC
  const performSingleCapture = useCallback(
    (burstSuffix?: string) => {
      const canvas = viewfinderCanvasRef.current;
      if (!canvas) return;

      // Optional mobile screen flash illumination
      if (screenFlashEnabled) {
        setIsScreenFlashing(true);
        setTimeout(() => setIsScreenFlashing(false), 180);
      }

      // Leaf shutter sound + mechanical curtain blackout
      soundEngine.playShutterClick(muted);
      setShutterCurtainClosed(true);
      setTimeout(() => setShutterCurtainClosed(false), 120);

      const { width: targetW, height: targetH } = getAspectRatioDimensions(aspectRatio, 1600);
      const exportCanvas = document.createElement('canvas');
      exportCanvas.width = targetW;
      exportCanvas.height = targetH;
      const exportCtx = exportCanvas.getContext('2d');

      const rawCanvas = document.createElement('canvas');
      rawCanvas.width = targetW;
      rawCanvas.height = targetH;
      const rawCtx = rawCanvas.getContext('2d');

      if (!exportCtx || !rawCtx) return;

      const isWebcamReady =
        sourceMode === 'webcam' &&
        cameraActive &&
        videoRef.current &&
        videoRef.current.readyState >= 2;

      const sourceEl = isWebcamReady ? videoRef.current! : simImageRef.current;
      if (!sourceEl) return;

      const srcW = isWebcamReady
        ? videoRef.current!.videoWidth || 1280
        : simImageRef.current!.naturalWidth || 1280;
      const srcH = isWebcamReady
        ? videoRef.current!.videoHeight || 720
        : simImageRef.current!.naturalHeight || 720;

      // 1. Render ungraded optical RAW frame for non-destructive darkroom editing
      renderOpticalFrame({
        ctx: rawCtx,
        source: sourceEl,
        sourceWidth: srcW,
        sourceHeight: srcH,
        targetWidth: targetW,
        targetHeight: targetH,
        exposure: { ...exposure, evCompensation: 0 },
        film: FILM_STOCKS[0],
        assist: { ...assist, zebraStripes: false, focusPeaking: false, dateStamp: false },
        optimalSceneFocusMeters: isWebcamReady ? 1.8 : currentSimulatedScene.optimalFocusMeters,
        isLiveCamera: isWebcamReady,
        includeOverlaysInRender: false,
      });

      // 2. Render graded frame with active film stock (without diagnostic zebras/peaking)
      renderOpticalFrame({
        ctx: exportCtx,
        source: sourceEl,
        sourceWidth: srcW,
        sourceHeight: srcH,
        targetWidth: targetW,
        targetHeight: targetH,
        exposure,
        film: activeFilm,
        assist: { ...assist, zebraStripes: false, focusPeaking: false },
        optimalSceneFocusMeters: isWebcamReady ? 1.8 : currentSimulatedScene.optimalFocusMeters,
        isLiveCamera: isWebcamReady,
        includeOverlaysInRender: false,
      });

      const renderedDataUrl = exportCanvas.toDataURL('image/jpeg', 0.94);
      const sourceDataUrl = rawCanvas.toDataURL('image/jpeg', 0.94);

      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const yy = String(now.getFullYear()).slice(-2);
      const mm = String(now.getMonth() + 1).padStart(2, '0');
      const dd = String(now.getDate()).padStart(2, '0');
      const fileStamp = `${yy}${mm}${dd}_${String(now.getHours()).padStart(2, '0')}${String(
        now.getMinutes()
      ).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}`;

      const frameNumber = frames.length + 1;
      const title = isWebcamReady
        ? `Optical Capture #${frameNumber}${burstSuffix || ''}`
        : `${currentSimulatedScene.title}${burstSuffix || ''}`;

      const newFrame: CapturedFrame = {
        id: `frame-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title,
        timestamp: `Today · ${timeStr}`,
        dateStampText: `'${yy} ${mm} ${dd}`,
        mediaType: 'photo',
        sourceDataUrl,
        renderedDataUrl,
        aspectRatio,
        favorite: false,
        exif: {
          cameraModel: 'Vespera M-System',
          lens: `Summilux ${exposure.focalLengthMm}mm f/${exposure.aperture}`,
          focalLength: `${exposure.focalLengthMm}mm`,
          aperture: `f/${exposure.aperture}`,
          shutterSpeed: `${exposure.shutterSpeed}s`,
          iso: exposure.iso,
          ev: `${exposure.evCompensation >= 0 ? '+' : ''}${exposure.evCompensation.toFixed(1)} EV`,
          kelvin: exposure.kelvin,
          filmStockName: activeFilm.name,
          dimensions: `${targetW} × ${targetH}`,
        },
        adjustments: {
          exposure: exposure.evCompensation,
          contrast: activeFilm.contrast,
          saturation: activeFilm.saturation,
          warmth: activeFilm.warmth,
          grain: activeFilm.grain,
          vignette: activeFilm.vignette,
          fade: activeFilm.fade,
          filmStockId: activeFilm.id,
          frameStyle: 'none',
          dateStamp: assist.dateStamp,
        },
      };

      setFrames((prev) => [newFrame, ...prev]);

      // Direct Download to Phone or PC immediately if Auto-Save is active
      if (autoDownloadOnCapture) {
        const filename = `VESPERA_${fileStamp}${burstSuffix ? burstSuffix.replace(/\s+/g, '') : ''}.jpg`;
        triggerDirectDownload(renderedDataUrl, filename);
        setCaptureToast({
          message: `Saved ${filename} directly to your device`,
          frame: newFrame,
        });
      } else {
        setCaptureToast({
          message: 'Captured to Contact Sheet',
          frame: newFrame,
        });
      }

      setTimeout(() => {
        setCaptureToast((prev) => (prev?.frame.id === newFrame.id ? null : prev));
      }, 4500);
    },
    [
      aspectRatio,
      assist,
      autoDownloadOnCapture,
      cameraActive,
      currentSimulatedScene,
      exposure,
      activeFilm,
      frames.length,
      muted,
      screenFlashEnabled,
      sourceMode,
    ]
  );

  // Handle Video Recording on Viewfinder Canvas
  const toggleVideoRecording = useCallback(() => {
    if (isRecordingVideo) {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setIsRecordingVideo(false);
      return;
    }

    const canvas = viewfinderCanvasRef.current;
    if (!canvas || typeof canvas.captureStream !== 'function') return;

    try {
      const stream = canvas.captureStream(30);
      const recorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
          ? 'video/webm;codecs=vp9'
          : 'video/webm',
      });

      recordedChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const videoBlobUrl = URL.createObjectURL(blob);
        const posterUrl = canvas.toDataURL('image/jpeg', 0.9);
        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        const videoFrame: CapturedFrame = {
          id: `video-${Date.now()}`,
          title: `Cine Clip #${frames.length + 1}`,
          timestamp: `Today · ${timeStr}`,
          dateStampText: "'26 09 26",
          mediaType: 'video',
          sourceDataUrl: posterUrl,
          renderedDataUrl: posterUrl,
          videoBlobUrl,
          aspectRatio,
          favorite: false,
          exif: {
            cameraModel: 'Vespera Cine-M',
            lens: `Summilux ${exposure.focalLengthMm}mm`,
            focalLength: `${exposure.focalLengthMm}mm`,
            aperture: `f/${exposure.aperture}`,
            shutterSpeed: '1/50s (180°)',
            iso: exposure.iso,
            ev: `${exposure.evCompensation.toFixed(1)} EV`,
            kelvin: exposure.kelvin,
            filmStockName: activeFilm.name,
            dimensions: `${canvas.width} × ${canvas.height} · 30fps`,
          },
          adjustments: {
            exposure: exposure.evCompensation,
            contrast: activeFilm.contrast,
            saturation: activeFilm.saturation,
            warmth: activeFilm.warmth,
            grain: activeFilm.grain,
            vignette: activeFilm.vignette,
            fade: activeFilm.fade,
            filmStockId: activeFilm.id,
            frameStyle: 'none',
            dateStamp: assist.dateStamp,
          },
        };

        setFrames((prev) => [videoFrame, ...prev]);
        if (autoDownloadOnCapture) {
          triggerDirectDownload(videoBlobUrl, `VESPERA_CLIP_${Date.now()}.webm`);
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      soundEngine.playTimerBeep(muted, true);
      setIsRecordingVideo(true);
      setRecordingDuration(0);
    } catch {
      // Fallback to photo capture if MediaRecorder unsupported
      performSingleCapture();
    }
  }, [
    activeFilm,
    aspectRatio,
    assist.dateStamp,
    autoDownloadOnCapture,
    exposure,
    frames.length,
    isRecordingVideo,
    muted,
    performSingleCapture,
  ]);

  // Video timer ticker
  useEffect(() => {
    if (!isRecordingVideo) return;
    const interval = setInterval(() => {
      setRecordingDuration((d) => d + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isRecordingVideo]);

  // Trigger Shutter with Self-Timer & Burst Support
  const handleShutterTrigger = useCallback(() => {
    if (countdown !== null) return;

    if (captureMode === 'video') {
      toggleVideoRecording();
      return;
    }

    const executeShot = () => {
      if (captureMode === 'burst') {
        performSingleCapture(' (1/3)');
        setTimeout(() => performSingleCapture(' (2/3)'), 220);
        setTimeout(() => performSingleCapture(' (3/3)'), 440);
      } else {
        performSingleCapture();
      }
    };

    if (timerSeconds > 0) {
      setCountdown(timerSeconds);
      soundEngine.playTimerBeep(muted, false);
      let remaining = timerSeconds;
      const timer = setInterval(() => {
        remaining -= 1;
        if (remaining > 0) {
          setCountdown(remaining);
          soundEngine.playTimerBeep(muted, false);
        } else {
          clearInterval(timer);
          setCountdown(null);
          soundEngine.playTimerBeep(muted, true);
          executeShot();
        }
      }, 1000);
    } else {
      executeShot();
    }
  }, [captureMode, countdown, muted, performSingleCapture, timerSeconds, toggleVideoRecording]);

  // Spacebar Keyboard Shortcut for PC Photographers
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (activeDarkroomFrame) return;
      if (e.code === 'Space' && document.activeElement?.tagName !== 'INPUT') {
        e.preventDefault();
        handleShutterTrigger();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeDarkroomFrame, handleShutterTrigger]);

  // Import existing photo from Phone or PC to grade & download
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const importedFrame: CapturedFrame = {
        id: `import-${Date.now()}`,
        title: file.name.replace(/\.[^/.]+$/, '') || 'Imported Frame',
        timestamp: 'Imported Just Now',
        dateStampText: "'26 09 26",
        mediaType: 'photo',
        sourceDataUrl: dataUrl,
        renderedDataUrl: dataUrl,
        aspectRatio: '3:2',
        favorite: false,
        exif: {
          cameraModel: 'External Optical Roll',
          lens: 'Summilux 35mm LUT',
          focalLength: '35mm',
          aperture: `f/${exposure.aperture}`,
          shutterSpeed: `${exposure.shutterSpeed}s`,
          iso: exposure.iso,
          ev: '0.0 EV',
          kelvin: 5500,
          filmStockName: activeFilm.name,
          dimensions: 'Native Resolution',
        },
        adjustments: {
          exposure: 0,
          contrast: activeFilm.contrast,
          saturation: activeFilm.saturation,
          warmth: activeFilm.warmth,
          grain: activeFilm.grain,
          vignette: activeFilm.vignette,
          fade: activeFilm.fade,
          filmStockId: activeFilm.id,
          frameStyle: 'film35',
          dateStamp: true,
        },
      };
      setFrames((prev) => [importedFrame, ...prev]);
      setActiveDarkroomFrame(importedFrame);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Tap on Viewfinder to Set Focus Reticle
  const handleViewfinderTap = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const xPct = Math.max(10, Math.min(90, ((e.clientX - rect.left) / rect.width) * 100));
    const yPct = Math.max(10, Math.min(90, ((e.clientY - rect.top) / rect.height) * 100));
    soundEngine.playDialDetent(muted);
    setFocusPoint({ x: xPct, y: yPct, active: true });
    setExposure((prev) => ({
      ...prev,
      autoFocus: true,
      focusDistance: currentSimulatedScene.optimalFocusMeters,
    }));
    setTimeout(() => {
      setFocusPoint((prev) => ({ ...prev, active: false }));
    }, 1800);
  };

  const cycleGrid = () => {
    soundEngine.playDialDetent(muted);
    const order: GridOverlayOption[] = ['thirds', 'golden', 'crosshair', 'none'];
    const next = order[(order.indexOf(assist.grid) + 1) % order.length];
    setAssist({ ...assist, grid: next });
  };

  const displayedFrames = showFavoritesOnly ? frames.filter((f) => f.favorite) : frames;

  return (
    <div className="min-h-screen bg-[#08080A] text-[#F4F4F0] flex flex-col justify-between select-none">
      {/* Screen Flash Illumination Overlay for Mobile Selfies */}
      {isScreenFlashing && (
        <div className="fixed inset-0 z-50 bg-white pointer-events-none transition-opacity duration-150" />
      )}

      {/* Hidden File Input for Importing Photos from Phone or PC */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImportFile}
        className="hidden"
      />

      {/* TOP OPTICAL TELEMETRY & HARDWARE BAR */}
      <header className="w-full bg-[#0E0E11] border-b border-white/10 px-3 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-2 z-30">
        {/* Brand & Sensor Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#E11D48] shadow-[0_0_10px_#E11D48]" />
            <span className="font-display font-bold tracking-wider text-sm sm:text-base uppercase text-[#F4F4F0]">
              Vespera Optics
            </span>
          </div>

          <span className="hidden md:inline-block text-white/20">|</span>

          {/* Source Switcher: Live Camera vs Optical Studio Simulator */}
          <div className="flex items-center bg-[#141418] p-0.5 rounded border border-white/10">
            <button
              onClick={() => startWebcam(facingMode)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-mono-tabular uppercase tracking-wider transition cursor-pointer ${
                sourceMode === 'webcam' && cameraActive
                  ? 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40 font-semibold'
                  : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Live Cam</span>
            </button>
            <button
              onClick={() => {
                soundEngine.playDialDetent(muted);
                setSourceMode('simulator');
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-mono-tabular uppercase tracking-wider transition cursor-pointer ${
                sourceMode === 'simulator'
                  ? 'bg-[#F2B705]/20 text-[#F2B705] border border-[#F2B705]/40 font-semibold'
                  : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Optical Sim</span>
            </button>
          </div>
        </div>

        {/* Center Live Exposure Readout Pill */}
        <div className="hidden xl:flex items-center gap-5 px-4 py-1 rounded bg-[#141418] border border-white/10 text-xs font-mono-tabular">
          <span>
            LENS <strong className="text-[#F2B705]">{exposure.focalLengthMm}mm</strong>
          </span>
          <span>
            IRIS <strong className="text-[#F4F4F0]">f/{exposure.aperture}</strong>
          </span>
          <span>
            SHUTTER <strong className="text-[#F4F4F0]">{exposure.shutterSpeed}s</strong>
          </span>
          <span>
            ISO <strong className="text-[#F4F4F0]">{exposure.iso}</strong>
          </span>
          <span>
            WB <strong className="text-[#F4F4F0]">{exposure.kelvin}K</strong>
          </span>
          <span>
            STOCK <strong className="text-[#F2B705]">{activeFilm.code}</strong>
          </span>
        </div>

        {/* Right Controls: Auto-Save to Phone/PC, Flip Lens, Import, Mute */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Direct Download Toggle */}
          <button
            onClick={() => {
              soundEngine.playDialDetent(muted);
              setAutoDownloadOnCapture(!autoDownloadOnCapture);
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded border text-[11px] font-mono-tabular uppercase tracking-wider transition cursor-pointer ${
              autoDownloadOnCapture
                ? 'bg-[#10B981]/15 border-[#10B981]/50 text-[#10B981]'
                : 'bg-[#141418] border-white/10 text-[#A1A1AA] hover:text-white'
            }`}
            title="Automatically download every captured photo directly to your phone or PC"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Direct Save:</span>
            <strong>{autoDownloadOnCapture ? 'ON' : 'OFF'}</strong>
          </button>

          {/* Front / Back Camera Flip Button (for Mobile & Multi-cam PCs) */}
          {sourceMode === 'webcam' && (
            <button
              onClick={handleFlipCamera}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-[#141418] hover:bg-[#1E1E24] border border-white/10 text-[11px] font-mono-tabular text-[#F4F4F0] transition cursor-pointer"
              title="Switch Front / Rear Camera"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#F2B705]" />
              <span className="hidden sm:inline">
                {facingMode === 'environment' ? 'Rear Lens' : 'Front Lens'}
              </span>
            </button>
          )}

          {/* Import Photo from Device */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-[#141418] hover:bg-[#1E1E24] border border-white/10 text-[11px] font-mono-tabular text-[#A1A1AA] hover:text-white transition cursor-pointer"
            title="Import a photo from your phone or PC to grade & download"
          >
            <Upload className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Import</span>
          </button>

          {/* Screen Flash Toggle */}
          <button
            onClick={() => setScreenFlashEnabled(!screenFlashEnabled)}
            className={`p-1.5 rounded border transition cursor-pointer ${
              screenFlashEnabled
                ? 'bg-[#F2B705]/20 border-[#F2B705] text-[#F2B705]'
                : 'bg-[#141418] border-white/10 text-[#A1A1AA] hover:text-white'
            }`}
            title="Screen Flash Illumination"
          >
            <Zap className="w-4 h-4" />
          </button>

          {/* Shutter Sound Mute Toggle */}
          <button
            onClick={() => setMuted(!muted)}
            className="p-1.5 rounded bg-[#141418] hover:bg-[#1E1E24] border border-white/10 text-[#A1A1AA] hover:text-white transition cursor-pointer"
            title={muted ? 'Unmute Mechanical Shutter' : 'Mute Mechanical Shutter'}
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Hidden Hardware Video Receiver */}
      <video ref={videoRef} playsInline muted className="hidden" />

      {/* MAIN OPTICAL VIEWFINDER & TACTILE CONTROL WORKSPACE */}
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* LEFT / CENTER VIEWFINDER STAGE */}
        <div className="flex-1 flex flex-col items-center justify-between p-2 sm:p-4 lg:p-6 bg-[#08080A] relative">
          {/* Camera Fallback Info Banner (if webcam blocked) */}
          {cameraError && sourceMode === 'simulator' && (
            <div className="w-full max-w-4xl mb-2 px-3 py-1.5 rounded bg-[#141418] border border-white/10 flex items-center justify-between gap-2 text-xs font-mono-tabular text-[#A1A1AA]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-[#F2B705] shrink-0" />
                <span>{cameraError}</span>
              </div>
              <button
                onClick={() => startWebcam(facingMode)}
                className="px-2 py-0.5 rounded bg-[#F2B705]/20 text-[#F2B705] hover:bg-[#F2B705]/30 transition shrink-0 cursor-pointer"
              >
                Retry Camera
              </button>
            </div>
          )}

          {/* VIEWFINDER FRAME CONTAINER */}
          <div className="relative w-full flex-1 flex items-center justify-center min-h-[340px] sm:min-h-[420px]">
            <div
              onClick={handleViewfinderTap}
              className="relative max-w-full max-h-[68vh] rounded-lg overflow-hidden border border-white/15 shadow-[0_24px_70px_rgba(0,0,0,0.9)] bg-[#050507] cursor-crosshair group"
            >
              {/* Live Graded Optical Canvas */}
              <canvas
                ref={viewfinderCanvasRef}
                className="block max-w-full max-h-[66vh] w-auto h-auto object-contain"
              />

              {/* Mechanical Leaf-Shutter Blackout Curtain */}
              <div
                className={`absolute inset-0 bg-[#050507] pointer-events-none transition-opacity duration-75 ${
                  shutterCurtainClosed ? 'opacity-100' : 'opacity-0'
                }`}
              />

              {/* Composition Grid Overlays (SVG Hairlines) */}
              {assist.grid === 'thirds' && (
                <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3">
                  <div className="border-r border-b border-white/20" />
                  <div className="border-r border-b border-white/20" />
                  <div className="border-b border-white/20" />
                  <div className="border-r border-b border-white/20" />
                  <div className="border-r border-b border-white/20" />
                  <div className="border-b border-white/20" />
                  <div className="border-r border-white/20" />
                  <div className="border-r border-white/20" />
                  <div />
                </div>
              )}

              {assist.grid === 'golden' && (
                <div
                  className="absolute inset-0 pointer-events-none grid"
                  style={{
                    gridTemplateColumns: '38.2% 23.6% 38.2%',
                    gridTemplateRows: '38.2% 23.6% 38.2%',
                  }}
                >
                  <div className="border-r border-b border-[#F2B705]/30" />
                  <div className="border-r border-b border-[#F2B705]/30" />
                  <div className="border-b border-[#F2B705]/30" />
                  <div className="border-r border-b border-[#F2B705]/30" />
                  <div className="border-r border-b border-[#F2B705]/30" />
                  <div className="border-b border-[#F2B705]/30" />
                  <div className="border-r border-[#F2B705]/30" />
                  <div className="border-r border-[#F2B705]/30" />
                  <div />
                </div>
              )}

              {assist.grid === 'crosshair' && (
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className="w-16 h-[1px] bg-[#F2B705]/60" />
                  <div className="h-16 w-[1px] bg-[#F2B705]/60 absolute" />
                  <div className="w-8 h-8 rounded-full border border-[#F2B705]/50 absolute" />
                </div>
              )}

              {/* Dual-Axis Horizon Level Indicator */}
              {assist.showHorizon && (
                <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 pointer-events-none flex items-center justify-center opacity-55">
                  <div className="w-12 h-[1px] bg-[#10B981]" />
                  <div className="w-2 h-2 rounded-full border border-[#10B981] mx-2" />
                  <div className="w-12 h-[1px] bg-[#10B981]" />
                </div>
              )}

              {/* Tap-to-Focus Reticle Box */}
              <div
                style={{ left: `${focusPoint.x}%`, top: `${focusPoint.y}%` }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-all duration-200 ${
                  focusPoint.active ? 'opacity-100 scale-100' : 'opacity-35 scale-95'
                }`}
              >
                <div className="w-14 h-14 border border-[#10B981] rounded-sm relative">
                  <span className="absolute -top-4 left-0 text-[9px] font-mono-tabular text-[#10B981] uppercase">
                    {exposure.autoFocus ? 'AF-S' : `${exposure.focusDistance.toFixed(1)}m`}
                  </span>
                </div>
              </div>

              {/* Top-Left HUD: Recording / Scene / Aspect Badge */}
              <div className="absolute top-3 left-3 flex flex-wrap items-center gap-2 pointer-events-none">
                {isRecordingVideo ? (
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#E11D48] text-white text-xs font-mono-tabular font-semibold shadow">
                    <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                    <span>REC 00:{String(recordingDuration).padStart(2, '0')}</span>
                  </div>
                ) : (
                  <div className="px-2.5 py-1 rounded bg-[#08080A]/75 backdrop-blur-md border border-white/15 text-[11px] font-mono-tabular text-[#F4F4F0] flex items-center gap-2">
                    <span className="text-[#F2B705] font-semibold">{aspectRatio}</span>
                    <span>·</span>
                    <span>{activeFilm.name}</span>
                  </div>
                )}
              </div>

              {/* Top-Right HUD: Live RGB & Luminance Histogram */}
              {assist.showHistogram && (
                <div className="absolute top-3 right-3 w-36 sm:w-44 p-2 rounded bg-[#08080A]/80 backdrop-blur-md border border-white/15 pointer-events-none">
                  <div className="flex items-center justify-between text-[9px] font-mono-tabular text-[#A1A1AA] mb-1">
                    <span>LUMA / RGB</span>
                    <span
                      className={
                        histogram.overexposedPct > 5 ? 'text-[#F2B705]' : 'text-[#10B981]'
                      }
                    >
                      {histogram.overexposedPct > 5
                        ? `CLIP ${histogram.overexposedPct}%`
                        : 'DYNAMIC OK'}
                    </span>
                  </div>
                  <div className="h-10 flex items-end gap-[2px]">
                    {histogram.luma.map((val, idx) => (
                      <div
                        key={idx}
                        className="flex-1 bg-white/75 rounded-t-[1px]"
                        style={{ height: `${Math.max(6, val)}%` }}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Self-Timer Countdown Overlay */}
              {countdown !== null && (
                <div className="absolute inset-0 bg-black/45 backdrop-blur-[2px] flex items-center justify-center pointer-events-none">
                  <span className="font-mono-tabular text-7xl sm:text-8xl font-bold text-[#F2B705] drop-shadow-[0_0_30px_rgba(242,183,5,0.6)] animate-pulse">
                    {countdown}
                  </span>
                </div>
              )}

              {/* Bottom Floating Lens Focal Switcher (28mm / 35mm / 50mm / 85mm) */}
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1 px-2 py-1 rounded-full bg-[#08080A]/85 backdrop-blur-md border border-white/15"
              >
                {FOCAL_LENGTHS.map((mm) => {
                  const active = exposure.focalLengthMm === mm;
                  return (
                    <button
                      key={mm}
                      onClick={() => {
                        soundEngine.playDialDetent(muted);
                        setExposure({ ...exposure, focalLengthMm: mm });
                      }}
                      className={`px-2.5 py-1 rounded-full text-xs font-mono-tabular transition cursor-pointer ${
                        active
                          ? 'bg-[#F2B705] text-[#08080A] font-bold'
                          : 'text-[#A1A1AA] hover:text-white'
                      }`}
                    >
                      {mm}mm
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Instant Toast Notification when Photo is Captured & Downloaded */}
            {captureToast && (
              <div className="absolute bottom-4 right-4 z-40 max-w-sm bg-[#121216]/95 backdrop-blur-xl border border-[#10B981]/50 rounded-lg p-3 shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-bottom-3">
                <img
                  src={captureToast.frame.renderedDataUrl}
                  alt={captureToast.frame.title}
                  className="w-12 h-12 rounded object-cover border border-white/15 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1 text-xs font-semibold text-[#10B981]">
                    <Check className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{captureToast.message}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1.5">
                    <button
                      onClick={() =>
                        shareOrDownloadPhoto(
                          captureToast.frame.renderedDataUrl,
                          `vespera-${Date.now()}.jpg`,
                          captureToast.frame.title
                        )
                      }
                      className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#F4F4F0] text-[#08080A] text-[11px] font-mono-tabular font-semibold cursor-pointer"
                    >
                      <Share2 className="w-3 h-3" />
                      <span>Save to Phone</span>
                    </button>
                    <button
                      onClick={() => setActiveDarkroomFrame(captureToast.frame)}
                      className="px-2 py-0.5 rounded bg-[#1E1E26] text-[#F2B705] border border-white/10 text-[11px] font-mono-tabular cursor-pointer"
                    >
                      Darkroom
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* PRIMARY TACTILE SHUTTER DECK (Optimized for Mobile Thumb & PC Click) */}
          <div className="w-full max-w-4xl mt-3 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 px-2">
            {/* Left Deck: Capture Mode (Single / Burst / Cine Video) + Timer */}
            <div className="flex items-center gap-2">
              <div className="flex items-center bg-[#141418] p-1 rounded border border-white/10">
                {(
                  [
                    { id: 'single', label: 'SINGLE', icon: Camera },
                    { id: 'burst', label: 'BURST', icon: Layers },
                    { id: 'video', label: 'CINE', icon: Video },
                  ] as const
                ).map((item) => {
                  const Icon = item.icon;
                  const active = captureMode === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        soundEngine.playDialDetent(muted);
                        setCaptureMode(item.id);
                      }}
                      className={`flex items-center gap-1 px-2.5 py-1.5 rounded text-[11px] font-mono-tabular transition cursor-pointer ${
                        active
                          ? 'bg-[#27272F] text-[#F2B705] font-semibold'
                          : 'text-[#A1A1AA] hover:text-white'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">{item.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Self-Timer Cycle Button */}
              <button
                onClick={() => {
                  soundEngine.playDialDetent(muted);
                  const nextTimer: TimerOption =
                    timerSeconds === 0 ? 3 : timerSeconds === 3 ? 10 : 0;
                  setTimerSeconds(nextTimer);
                }}
                className={`flex items-center gap-1 px-2.5 py-2 rounded border text-xs font-mono-tabular transition cursor-pointer ${
                  timerSeconds > 0
                    ? 'bg-[#F2B705]/15 border-[#F2B705] text-[#F2B705]'
                    : 'bg-[#141418] border-white/10 text-[#A1A1AA] hover:text-white'
                }`}
                title="Self-Timer Delay"
              >
                <Timer className="w-4 h-4" />
                <span>{timerSeconds > 0 ? `${timerSeconds}s` : 'OFF'}</span>
              </button>
            </div>

            {/* Center Mechanical Shutter Release Button */}
            <div className="flex items-center gap-4">
              <button
                onClick={handleShutterTrigger}
                aria-label="Trigger Camera Shutter"
                className="group relative w-16 h-16 sm:w-20 sm:h-20 rounded-full p-1.5 bg-gradient-to-b from-[#3F3F46] to-[#18181B] border-2 border-white/30 shadow-[0_0_30px_rgba(0,0,0,0.9)] active:scale-95 transition flex items-center justify-center cursor-pointer"
              >
                <span
                  className={`w-full h-full rounded-full transition-all flex items-center justify-center ${
                    captureMode === 'video'
                      ? isRecordingVideo
                        ? 'bg-[#E11D48] scale-75 rounded-lg'
                        : 'bg-[#E11D48] group-hover:bg-[#F43F5E]'
                      : 'bg-[#F4F4F0] group-hover:bg-white'
                  }`}
                >
                  <span
                    className={`w-4 h-4 rounded-full ${
                      captureMode === 'video' ? 'bg-white' : 'bg-[#E11D48]'
                    }`}
                  />
                </span>
              </button>
            </div>

            {/* Right Deck: Quick Last Photo Download / Open Darkroom */}
            <div className="flex items-center gap-2">
              {frames[0] && (
                <div className="flex items-center gap-2 bg-[#141418] p-1.5 rounded border border-white/10">
                  <button
                    onClick={() => setActiveDarkroomFrame(frames[0])}
                    className="relative w-10 h-10 rounded overflow-hidden border border-white/20 group cursor-pointer"
                    title="Open Latest Photo in Darkroom"
                  >
                    <img
                      src={frames[0].renderedDataUrl}
                      alt={frames[0].title}
                      className="w-full h-full object-cover group-hover:scale-105 transition"
                    />
                  </button>
                  <div className="hidden sm:flex flex-col">
                    <button
                      onClick={() => {
                        soundEngine.playShutterClick(muted);
                        triggerDirectDownload(
                          frames[0].renderedDataUrl,
                          `VESPERA_LATEST_${Date.now()}.jpg`
                        );
                      }}
                      className="flex items-center gap-1 text-[11px] font-mono-tabular text-[#10B981] hover:underline cursor-pointer"
                    >
                      <Download className="w-3 h-3" />
                      <span>Save Latest</span>
                    </button>
                    <button
                      onClick={() => setActiveDarkroomFrame(frames[0])}
                      className="text-[10px] font-mono-tabular text-[#A1A1AA] hover:text-white text-left cursor-pointer"
                    >
                      Grade in Darkroom
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT PRECISION OPTICAL & FILM CONTROL SIDEBAR */}
        <aside className="w-full lg:w-[360px] bg-[#101013] border-t lg:border-t-0 lg:border-l border-white/10 flex flex-col justify-between p-4 sm:p-5 overflow-y-auto">
          {/* Mobile Tab Switcher for Compact Screens */}
          <div className="grid grid-cols-3 gap-1 bg-[#16161B] p-1 rounded border border-white/10 mb-4">
            {(
              [
                { id: 'optics', label: 'Optics & Exposure' },
                { id: 'film', label: 'Film Stocks' },
                { id: 'assist', label: 'Viewfinder HUD' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  soundEngine.playDialDetent(muted);
                  setMobileControlTab(tab.id);
                }}
                className={`py-1.5 px-2 rounded text-[11px] font-mono-tabular uppercase tracking-wider transition cursor-pointer ${
                  mobileControlTab === tab.id
                    ? 'bg-[#F2B705] text-[#08080A] font-semibold'
                    : 'text-[#A1A1AA] hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="space-y-5 flex-1">
            {/* TAB 1: OPTICS & MANUAL EXPOSURE DIALS */}
            {mobileControlTab === 'optics' && (
              <div className="space-y-4">
                {/* Optical Scene Selector when in Simulator Mode */}
                {sourceMode === 'simulator' && (
                  <div className="p-3 rounded bg-[#15151A] border border-[#F2B705]/30 space-y-2">
                    <div className="flex items-center justify-between text-[11px] font-mono-tabular text-[#F2B705]">
                      <span>OPTICAL TEST SUBJECT</span>
                      <span>35MM REFERENCE</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1.5">
                      {SIMULATED_SCENES.map((scene, idx) => (
                        <button
                          key={scene.id}
                          onClick={() => {
                            soundEngine.playDialDetent(muted);
                            setActiveSceneIndex(idx);
                            setSelectedFilmId(scene.defaultFilmId);
                            setExposure((prev) => ({
                              ...prev,
                              aperture: scene.exifPreset.aperture,
                              shutterSpeed: scene.exifPreset.shutterSpeed,
                              iso: scene.exifPreset.iso,
                              focalLengthMm: scene.exifPreset.focalLengthMm,
                              kelvin: scene.baseKelvin,
                              focusDistance: scene.optimalFocusMeters,
                            }));
                          }}
                          className={`p-1.5 rounded border text-left transition cursor-pointer ${
                            activeSceneIndex === idx
                              ? 'bg-[#22222A] border-[#F2B705] text-white'
                              : 'bg-[#101013] border-white/10 text-[#A1A1AA] hover:text-white'
                          }`}
                        >
                          <img
                            src={scene.imageUrl}
                            alt={scene.title}
                            className="w-full h-10 object-cover rounded mb-1"
                          />
                          <div className="text-[10px] font-mono-tabular truncate">
                            {scene.title.split(' ')[0]}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Aperture Iris Stops */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-mono-tabular">
                    <span className="text-[#A1A1AA] flex items-center gap-1.5">
                      <Aperture className="w-3.5 h-3.5 text-[#F2B705]" />
                      <span>APERTURE (IRIS)</span>
                    </span>
                    <span className="text-[#F4F4F0] font-semibold">f/{exposure.aperture}</span>
                  </div>
                  <div className="grid grid-cols-4 gap-1.5">
                    {APERTURE_STOPS.map((stop) => (
                      <button
                        key={stop}
                        onClick={() => {
                          soundEngine.playDialDetent(muted);
                          setExposure({ ...exposure, aperture: stop });
                        }}
                        className={`py-1.5 rounded border text-xs font-mono-tabular transition cursor-pointer ${
                          exposure.aperture === stop
                            ? 'bg-[#F2B705] text-[#08080A] border-[#F2B705] font-semibold'
                            : 'bg-[#15151A] text-[#A1A1AA] border-white/10 hover:text-white'
                        }`}
                      >
                        f/{stop}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Shutter Speed Dial */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-mono-tabular">
                    <span className="text-[#A1A1AA]">SHUTTER SPEED</span>
                    <span className="text-[#F4F4F0] font-semibold">{exposure.shutterSpeed}s</span>
                  </div>
                  <div className="grid grid-cols-5 gap-1">
                    {SHUTTER_SPEEDS.map((spd) => (
                      <button
                        key={spd}
                        onClick={() => {
                          soundEngine.playDialDetent(muted);
                          setExposure({ ...exposure, shutterSpeed: spd });
                        }}
                        className={`py-1.5 rounded border text-[11px] font-mono-tabular transition cursor-pointer ${
                          exposure.shutterSpeed === spd
                            ? 'bg-[#F4F4F0] text-[#08080A] border-[#F4F4F0] font-semibold'
                            : 'bg-[#15151A] text-[#A1A1AA] border-white/10 hover:text-white'
                        }`}
                      >
                        {spd}
                      </button>
                    ))}
                  </div>
                </div>

                {/* ISO Sensitivity */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-mono-tabular">
                    <span className="text-[#A1A1AA]">ISO SENSITIVITY</span>
                    <span className="text-[#F4F4F0] font-semibold">ISO {exposure.iso}</span>
                  </div>
                  <div className="grid grid-cols-4 gap-1.5">
                    {ISO_STOPS.map((isoVal) => (
                      <button
                        key={isoVal}
                        onClick={() => {
                          soundEngine.playDialDetent(muted);
                          setExposure({ ...exposure, iso: isoVal });
                        }}
                        className={`py-1.5 rounded border text-xs font-mono-tabular transition cursor-pointer ${
                          exposure.iso === isoVal
                            ? 'bg-[#F2B705] text-[#08080A] border-[#F2B705] font-semibold'
                            : 'bg-[#15151A] text-[#A1A1AA] border-white/10 hover:text-white'
                        }`}
                      >
                        {isoVal}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Exposure Compensation (EV) */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-mono-tabular">
                    <span className="text-[#A1A1AA]">EXPOSURE COMP (EV)</span>
                    <span className="text-[#F2B705] font-semibold">
                      {exposure.evCompensation >= 0
                        ? `+${exposure.evCompensation.toFixed(1)}`
                        : exposure.evCompensation.toFixed(1)}{' '}
                      EV
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-2.5"
                    max="2.5"
                    step="0.1"
                    value={exposure.evCompensation}
                    onChange={(e) =>
                      setExposure({ ...exposure, evCompensation: parseFloat(e.target.value) })
                    }
                    className="optical-slider"
                  />
                </div>

                {/* Color Temperature (Kelvin) */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-mono-tabular">
                    <span className="text-[#A1A1AA] flex items-center gap-1">
                      <Sun className="w-3.5 h-3.5 text-[#F2B705]" />
                      <span>WHITE BALANCE</span>
                    </span>
                    <span className="text-[#F4F4F0]">{exposure.kelvin}K</span>
                  </div>
                  <input
                    type="range"
                    min="2800"
                    max="8500"
                    step="100"
                    value={exposure.kelvin}
                    onChange={(e) =>
                      setExposure({ ...exposure, kelvin: parseInt(e.target.value, 10) })
                    }
                    className="optical-slider"
                  />
                </div>

                {/* Manual Focus Ring & Distance */}
                <div className="space-y-1.5 pt-1 border-t border-white/10">
                  <div className="flex items-center justify-between text-xs font-mono-tabular">
                    <span className="text-[#A1A1AA]">FOCUS RING</span>
                    <button
                      onClick={() =>
                        setExposure({ ...exposure, autoFocus: !exposure.autoFocus })
                      }
                      className={`px-2 py-0.5 rounded text-[10px] font-mono-tabular border cursor-pointer ${
                        exposure.autoFocus
                          ? 'bg-[#10B981]/20 border-[#10B981] text-[#10B981]'
                          : 'bg-[#F2B705]/20 border-[#F2B705] text-[#F2B705]'
                      }`}
                    >
                      {exposure.autoFocus ? 'AF-S LOCKED' : `MF ${exposure.focusDistance.toFixed(1)}m`}
                    </button>
                  </div>
                  <input
                    type="range"
                    min="0.4"
                    max="8.0"
                    step="0.1"
                    value={exposure.focusDistance}
                    onChange={(e) =>
                      setExposure({
                        ...exposure,
                        autoFocus: false,
                        focusDistance: parseFloat(e.target.value),
                      })
                    }
                    className="optical-slider"
                  />
                </div>
              </div>
            )}

            {/* TAB 2: ANALOG FILM EMULATION STOCKS */}
            {mobileControlTab === 'film' && (
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-xs font-mono-tabular text-[#A1A1AA]">
                  <span className="flex items-center gap-1.5">
                    <Film className="w-3.5 h-3.5 text-[#F2B705]" />
                    <span>LIVE FILM EMULATION LUT</span>
                  </span>
                  <span className="text-[#F2B705]">{activeFilm.code}</span>
                </div>

                <div className="space-y-2">
                  {FILM_STOCKS.map((stock) => {
                    const selected = stock.id === selectedFilmId;
                    return (
                      <button
                        key={stock.id}
                        onClick={() => {
                          soundEngine.playDialDetent(muted);
                          setSelectedFilmId(stock.id);
                        }}
                        className={`w-full p-3 rounded border text-left transition cursor-pointer ${
                          selected
                            ? 'bg-[#1C1C23] border-[#F2B705] shadow-[0_0_20px_rgba(242,183,5,0.12)]'
                            : 'bg-[#15151A] border-white/10 hover:border-white/25'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-[#F4F4F0]">
                            {stock.name}
                          </span>
                          <span
                            className="px-1.5 py-0.5 rounded text-[10px] font-mono-tabular font-semibold"
                            style={{
                              backgroundColor: `${stock.accentHex}20`,
                              color: stock.accentHex,
                            }}
                          >
                            {stock.code}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#A1A1AA] mt-1 leading-relaxed">
                          {stock.description}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 3: VIEWFINDER ASSIST, ASPECT RATIO & DIAGNOSTICS */}
            {mobileControlTab === 'assist' && (
              <div className="space-y-4">
                {/* Aspect Ratio Framing */}
                <div className="space-y-1.5">
                  <span className="block text-xs font-mono-tabular text-[#A1A1AA]">
                    SENSOR ASPECT GATE
                  </span>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(['3:2', '16:9', '4:3', '1:1'] as AspectRatioOption[]).map((ratio) => (
                      <button
                        key={ratio}
                        onClick={() => {
                          soundEngine.playDialDetent(muted);
                          setAspectRatio(ratio);
                        }}
                        className={`py-2 rounded border text-xs font-mono-tabular transition cursor-pointer ${
                          aspectRatio === ratio
                            ? 'bg-[#F2B705] text-[#08080A] border-[#F2B705] font-semibold'
                            : 'bg-[#15151A] text-[#A1A1AA] border-white/10 hover:text-white'
                        }`}
                      >
                        {ratio}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Diagnostic Overlays */}
                <div className="space-y-2">
                  <span className="block text-xs font-mono-tabular text-[#A1A1AA]">
                    OPTICAL HUD OVERLAYS
                  </span>

                  <button
                    onClick={cycleGrid}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded bg-[#15151A] border border-white/10 text-xs font-mono-tabular cursor-pointer"
                  >
                    <span className="flex items-center gap-2 text-[#F4F4F0]">
                      <Grid className="w-4 h-4 text-[#F2B705]" />
                      <span>FRAMING RETICLE</span>
                    </span>
                    <span className="uppercase text-[#F2B705]">{assist.grid}</span>
                  </button>

                  <button
                    onClick={() =>
                      setAssist({ ...assist, focusPeaking: !assist.focusPeaking })
                    }
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded border text-xs font-mono-tabular cursor-pointer ${
                      assist.focusPeaking
                        ? 'bg-[#10B981]/15 border-[#10B981] text-[#10B981]'
                        : 'bg-[#15151A] border-white/10 text-[#A1A1AA]'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      <span>FOCUS PEAKING (EMERALD EDGE)</span>
                    </span>
                    <span>{assist.focusPeaking ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    onClick={() =>
                      setAssist({ ...assist, zebraStripes: !assist.zebraStripes })
                    }
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded border text-xs font-mono-tabular cursor-pointer ${
                      assist.zebraStripes
                        ? 'bg-[#F2B705]/15 border-[#F2B705] text-[#F2B705]'
                        : 'bg-[#15151A] border-white/10 text-[#A1A1AA]'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Sliders className="w-4 h-4" />
                      <span>95% IRE ZEBRA WARNING</span>
                    </span>
                    <span>{assist.zebraStripes ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    onClick={() =>
                      setAssist({ ...assist, showHorizon: !assist.showHorizon })
                    }
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded border text-xs font-mono-tabular cursor-pointer ${
                      assist.showHorizon
                        ? 'bg-[#15151A] border-white/25 text-[#F4F4F0]'
                        : 'bg-[#15151A] border-white/10 text-[#A1A1AA]'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Compass className="w-4 h-4 text-[#10B981]" />
                      <span>GYRO HORIZON LEVEL</span>
                    </span>
                    <span>{assist.showHorizon ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    onClick={() =>
                      setAssist({ ...assist, dateStamp: !assist.dateStamp })
                    }
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded border text-xs font-mono-tabular cursor-pointer ${
                      assist.dateStamp
                        ? 'bg-[#15151A] border-[#F2B705]/50 text-[#F2B705]'
                        : 'bg-[#15151A] border-white/10 text-[#A1A1AA]'
                    }`}
                  >
                    <span>QUARTZ DATE STAMP (&apos;26 09 26)</span>
                    <span>{assist.dateStamp ? 'ON' : 'OFF'}</span>
                  </button>

                  <button
                    onClick={() =>
                      setAssist({
                        ...assist,
                        mirrorFrontCamera: !assist.mirrorFrontCamera,
                      })
                    }
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded bg-[#15151A] border border-white/10 text-xs font-mono-tabular text-[#A1A1AA] hover:text-white cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <FlipHorizontal className="w-4 h-4" />
                      <span>MIRROR LIVE SELFIE</span>
                    </span>
                    <span>{assist.mirrorFrontCamera ? 'ON' : 'OFF'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Mobile & PC Direct Download Status Box */}
          <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-[11px] font-mono-tabular text-[#A1A1AA]">
            <div className="flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-[#10B981]" />
              <span>Mobile &amp; PC Direct Save Ready</span>
            </div>
            <span className="text-[#F4F4F0]">{frames.length} Frames</span>
          </div>
        </aside>
      </main>

      {/* BOTTOM 35MM CONTACT SHEET FILMSTRIP & INSTANT DOWNLOAD TRAY */}
      <section
        ref={contactSheetRef}
        className="w-full bg-[#0C0C0F] border-t border-white/10 px-4 sm:px-6 py-3"
      >
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs font-mono-tabular uppercase tracking-wider text-[#F4F4F0]">
              <ImageIcon className="w-4 h-4 text-[#F2B705]" />
              <span>35mm Contact Sheet ({displayedFrames.length})</span>
            </div>
            <button
              onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
              className={`flex items-center gap-1 px-2 py-0.5 rounded border text-[11px] font-mono-tabular transition cursor-pointer ${
                showFavoritesOnly
                  ? 'bg-[#E11D48]/20 border-[#E11D48] text-[#E11D48]'
                  : 'bg-[#141418] border-white/10 text-[#A1A1AA] hover:text-white'
              }`}
            >
              <Heart className="w-3 h-3" />
              <span>Favorites</span>
            </button>
          </div>

          <span className="text-[11px] font-mono-tabular text-[#A1A1AA]">
            Click any photo to grade in Darkroom or tap Download icon to save directly to Phone / PC
          </span>
        </div>

        {/* Horizontal Film Roll Strip */}
        <div className="flex items-center gap-3 overflow-x-auto pb-1">
          {displayedFrames.map((frame, index) => (
            <div
              key={frame.id}
              className="group relative shrink-0 w-44 sm:w-48 bg-[#141418] rounded border border-white/10 hover:border-[#F2B705]/60 overflow-hidden transition"
            >
              {/* Top 35mm Rebate Code Bar */}
              <div className="flex items-center justify-between px-2 py-1 bg-[#09090B] border-b border-white/5 text-[9px] font-mono-tabular text-[#F2B705]/80">
                <span>{String(displayedFrames.length - index).padStart(2, '0')}A</span>
                <span className="truncate max-w-[90px]">{frame.exif.filmStockName}</span>
              </div>

              {/* Thumbnail Image */}
              <div
                onClick={() => setActiveDarkroomFrame(frame)}
                className="relative h-24 w-full bg-black cursor-pointer overflow-hidden"
              >
                <img
                  src={frame.renderedDataUrl}
                  alt={frame.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition flex items-end justify-between p-1.5">
                  <span className="text-[10px] font-mono-tabular text-white flex items-center gap-1">
                    <Maximize2 className="w-3 h-3 text-[#F2B705]" />
                    <span>Darkroom</span>
                  </span>
                </div>
              </div>

              {/* Bottom Action Bar: Direct Download to Phone/PC + Share + Delete */}
              <div className="flex items-center justify-between px-2 py-1.5 bg-[#121216] border-t border-white/5">
                <button
                  onClick={() => {
                    soundEngine.playShutterClick(muted);
                    const cleanTitle = frame.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
                    triggerDirectDownload(frame.renderedDataUrl, `vespera-${cleanTitle}.jpg`);
                  }}
                  className="flex items-center gap-1 px-2 py-1 rounded bg-[#F4F4F0] hover:bg-white text-[#08080A] text-[10px] font-mono-tabular font-semibold transition cursor-pointer"
                  title="Download Photo Directly to Phone or PC"
                >
                  <Download className="w-3 h-3" />
                  <span>Save</span>
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      const cleanTitle = frame.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
                      shareOrDownloadPhoto(
                        frame.renderedDataUrl,
                        `vespera-${cleanTitle}.jpg`,
                        frame.title
                      );
                    }}
                    className="p-1 rounded hover:bg-white/10 text-[#A1A1AA] hover:text-white transition cursor-pointer"
                    title="Share / Save to Phone Camera Roll"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() =>
                      setFrames((prev) =>
                        prev.map((f) =>
                          f.id === frame.id ? { ...f, favorite: !f.favorite } : f
                        )
                      )
                    }
                    className={`p-1 rounded hover:bg-white/10 transition cursor-pointer ${
                      frame.favorite ? 'text-[#E11D48]' : 'text-[#A1A1AA] hover:text-white'
                    }`}
                    title="Favorite"
                  >
                    <Heart className={`w-3.5 h-3.5 ${frame.favorite ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={() =>
                      setFrames((prev) => prev.filter((f) => f.id !== frame.id))
                    }
                    className="p-1 rounded hover:bg-[#E11D48]/20 text-[#A1A1AA] hover:text-[#E11D48] transition cursor-pointer"
                    title="Delete Frame"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* NON-DESTRUCTIVE DARKROOM & LIGHTBOX MODAL */}
      {activeDarkroomFrame && (
        <DarkroomModal
          frame={activeDarkroomFrame}
          allFrames={frames}
          muted={muted}
          onClose={() => setActiveDarkroomFrame(null)}
          onSelectFrame={(f) => setActiveDarkroomFrame(f)}
          onUpdateFrame={(updated) => {
            setFrames((prev) => prev.map((f) => (f.id === updated.id ? updated : f)));
            setActiveDarkroomFrame(updated);
          }}
          onDeleteFrame={(id) => {
            setFrames((prev) => prev.filter((f) => f.id !== id));
          }}
          onToggleFavorite={(id) => {
            setFrames((prev) =>
              prev.map((f) => (f.id === id ? { ...f, favorite: !f.favorite } : f))
            );
            setActiveDarkroomFrame((prev) =>
              prev && prev.id === id ? { ...prev, favorite: !prev.favorite } : prev
            );
          }}
        />
      )}
    </div>
  );
}
