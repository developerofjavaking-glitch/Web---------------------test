import {
  AspectRatioOption,
  AssistOverlays,
  DarkroomAdjustments,
  ExposureSettings,
  FilmStockProfile,
} from '../types/camera';

// Synthesize mechanical leaf shutter click & timer beep via Web Audio API
class SoundEngine {
  private ctx: AudioContext | null = null;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playShutterClick(muted: boolean) {
    if (muted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    // 1. Crisp mechanical leaf-shutter blade snap (filtered white noise burst)
    const bufferSize = ctx.sampleRate * 0.045;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.008));
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1800, now);
    filter.Q.setValueAtTime(1.8, now);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.45, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.04);

    whiteNoise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    whiteNoise.start(now);

    // 2. Second curtain return click (28ms later)
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(240, now + 0.028);
    osc.frequency.exponentialRampToValueAtTime(65, now + 0.055);

    oscGain.gain.setValueAtTime(0.001, now);
    oscGain.gain.setValueAtTime(0.3, now + 0.028);
    oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

    osc.connect(oscGain);
    oscGain.connect(ctx.destination);
    osc.start(now + 0.028);
    osc.stop(now + 0.065);
  }

  public playDialDetent(muted: boolean) {
    if (muted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(950, now);
    osc.frequency.exponentialRampToValueAtTime(320, now + 0.012);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.012);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.014);
  }

  public playTimerBeep(muted: boolean, finalBeep = false) {
    if (muted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(finalBeep ? 1760 : 880, now);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.095);
  }
}

export const soundEngine = new SoundEngine();

export function getAspectRatioDimensions(
  aspectRatio: AspectRatioOption,
  baseWidth = 1280
): { width: number; height: number; ratioValue: number } {
  switch (aspectRatio) {
    case '16:9':
      return { width: baseWidth, height: Math.round((baseWidth * 9) / 16), ratioValue: 16 / 9 };
    case '3:2':
      return { width: baseWidth, height: Math.round((baseWidth * 2) / 3), ratioValue: 3 / 2 };
    case '4:3':
      return { width: baseWidth, height: Math.round((baseWidth * 3) / 4), ratioValue: 4 / 3 };
    case '1:1':
      return { width: baseWidth, height: baseWidth, ratioValue: 1 };
  }
}

export interface HistogramData {
  luma: number[];
  r: number[];
  g: number[];
  b: number[];
  overexposedPct: number;
  underexposedPct: number;
}

// Compute 32-bin RGB & Luminance histogram from canvas context
export function computeHistogram(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number
): HistogramData {
  const bins = 32;
  const luma = new Array(bins).fill(0);
  const r = new Array(bins).fill(0);
  const g = new Array(bins).fill(0);
  const b = new Array(bins).fill(0);

  // Sample a downscaled region or stride for zero-latency 60fps performance
  const sampleStep = 16;
  const imgData = ctx.getImageData(0, 0, width, height).data;
  let totalSamples = 0;
  let overCount = 0;
  let underCount = 0;

  for (let i = 0; i < imgData.length; i += 4 * sampleStep) {
    const rv = imgData[i];
    const gv = imgData[i + 1];
    const bv = imgData[i + 2];
    const lv = Math.round(0.299 * rv + 0.587 * gv + 0.114 * bv);

    r[Math.min(bins - 1, Math.floor((rv / 256) * bins))]++;
    g[Math.min(bins - 1, Math.floor((gv / 256) * bins))]++;
    b[Math.min(bins - 1, Math.floor((bv / 256) * bins))]++;
    luma[Math.min(bins - 1, Math.floor((lv / 256) * bins))]++;

    if (lv >= 245) overCount++;
    if (lv <= 10) underCount++;
    totalSamples++;
  }

  const maxVal = Math.max(...luma, ...r, ...g, ...b, 1);
  return {
    luma: luma.map((v) => Math.round((v / maxVal) * 100)),
    r: r.map((v) => Math.round((v / maxVal) * 100)),
    g: g.map((v) => Math.round((v / maxVal) * 100)),
    b: b.map((v) => Math.round((v / maxVal) * 100)),
    overexposedPct: totalSamples ? Math.round((overCount / totalSamples) * 100) : 0,
    underexposedPct: totalSamples ? Math.round((underCount / totalSamples) * 100) : 0,
  };
}

// Render live viewfinder or darkroom frame onto target canvas
export function renderOpticalFrame(params: {
  ctx: CanvasRenderingContext2D;
  source: HTMLVideoElement | HTMLImageElement;
  sourceWidth: number;
  sourceHeight: number;
  targetWidth: number;
  targetHeight: number;
  exposure: ExposureSettings;
  film: FilmStockProfile;
  assist: AssistOverlays;
  optimalSceneFocusMeters?: number;
  isLiveCamera: boolean;
  includeOverlaysInRender: boolean; // false when capturing photo to save, true for live HUD if needed
}) {
  const {
    ctx,
    source,
    sourceWidth,
    sourceHeight,
    targetWidth,
    targetHeight,
    exposure,
    film,
    assist,
    optimalSceneFocusMeters = 2.0,
    isLiveCamera,
    includeOverlaysInRender,
  } = params;

  if (!sourceWidth || !sourceHeight) return;

  ctx.save();
  ctx.clearRect(0, 0, targetWidth, targetHeight);

  // 1. Calculate optical focal zoom & center crop to fit target aspect ratio
  const zoomFactor =
    exposure.focalLengthMm === 28
      ? 1.0
      : exposure.focalLengthMm === 35
      ? 1.18
      : exposure.focalLengthMm === 50
      ? 1.45
      : 1.85;

  const targetRatio = targetWidth / targetHeight;
  const sourceRatio = sourceWidth / sourceHeight;

  let cropW = sourceWidth;
  let cropH = sourceHeight;

  if (sourceRatio > targetRatio) {
    cropW = sourceHeight * targetRatio;
  } else {
    cropH = sourceWidth / targetRatio;
  }

  cropW /= zoomFactor;
  cropH /= zoomFactor;

  const cropX = (sourceWidth - cropW) / 2;
  const cropY = (sourceHeight - cropH) / 2;

  // 2. Compute optical brightness, contrast, saturation & focus defocus blur
  // Exposure compensation + film contrast/saturation
  const evMultiplier = Math.pow(2, exposure.evCompensation * 0.45);
  const brightnessPct = Math.max(30, Math.min(220, Math.round(100 * evMultiplier)));
  const contrastPct = Math.max(50, Math.min(180, 100 + film.contrast));
  const saturatePct = Math.max(0, Math.min(220, film.saturation));

  // Calculate defocus blur if manual focus or aperture is wide
  let blurPx = 0;
  if (!exposure.autoFocus) {
    const focusDelta = Math.abs(exposure.focusDistance - optimalSceneFocusMeters);
    // Wider aperture (smaller f-number) increases out-of-focus blur radius
    const apertureFactor = Math.max(0.25, 4.0 / exposure.aperture);
    blurPx = Math.min(12, focusDelta * apertureFactor * 0.9);
  }

  ctx.filter = `brightness(${brightnessPct}%) contrast(${contrastPct}%) saturate(${saturatePct}%)${
    blurPx > 0.25 ? ` blur(${blurPx.toFixed(1)}px)` : ''
  }`;

  if (isLiveCamera && assist.mirrorFrontCamera) {
    ctx.translate(targetWidth, 0);
    ctx.scale(-1, 1);
  }

  ctx.drawImage(source, cropX, cropY, cropW, cropH, 0, 0, targetWidth, targetHeight);

  if (isLiveCamera && assist.mirrorFrontCamera) {
    ctx.setTransform(1, 0, 0, 1, 0, 0);
  }
  ctx.filter = 'none';

  // 3. Apply Kelvin White Balance & Film Warmth/Tint Color Matrix Overlay
  const kelvinShift = (exposure.kelvin - 5500) / 100; // -27 to +30
  const totalWarmth = kelvinShift + film.warmth;

  if (Math.abs(totalWarmth) > 2 || Math.abs(film.tint) > 2) {
    ctx.save();
    ctx.globalCompositeOperation = 'soft-light';
    if (totalWarmth > 0) {
      ctx.fillStyle = `rgba(255, 168, 52, ${Math.min(0.38, Math.abs(totalWarmth) * 0.006)})`;
    } else {
      ctx.fillStyle = `rgba(56, 152, 255, ${Math.min(0.38, Math.abs(totalWarmth) * 0.006)})`;
    }
    ctx.fillRect(0, 0, targetWidth, targetHeight);
    ctx.restore();
  }

  // 4. Lifted matte blacks (Film Fade)
  if (film.fade > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    const fadeAlpha = (film.fade / 100) * 0.18;
    ctx.fillStyle = `rgba(28, 26, 32, ${fadeAlpha})`;
    ctx.fillRect(0, 0, targetWidth, targetHeight);
    ctx.restore();
  }

  // 5. Tungsten Halation glow on highlights
  if (film.halation > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    const halationGrad = ctx.createRadialGradient(
      targetWidth * 0.5,
      targetHeight * 0.42,
      targetWidth * 0.05,
      targetWidth * 0.5,
      targetHeight * 0.42,
      targetWidth * 0.65
    );
    const alpha = (film.halation / 100) * 0.16;
    halationGrad.addColorStop(0, `rgba(235, 45, 45, ${alpha})`);
    halationGrad.addColorStop(1, 'rgba(235, 45, 45, 0)');
    ctx.fillStyle = halationGrad;
    ctx.fillRect(0, 0, targetWidth, targetHeight);
    ctx.restore();
  }

  // 6. Optical Lens Vignette (stronger at f/1.4, lighter at f/8+)
  const apertureVignetteBoost = exposure.aperture <= 2.0 ? 16 : exposure.aperture <= 4.0 ? 8 : 0;
  const totalVignette = Math.min(100, film.vignette + apertureVignetteBoost);
  if (totalVignette > 0) {
    ctx.save();
    const radGrad = ctx.createRadialGradient(
      targetWidth / 2,
      targetHeight / 2,
      Math.min(targetWidth, targetHeight) * 0.28,
      targetWidth / 2,
      targetHeight / 2,
      Math.max(targetWidth, targetHeight) * 0.72
    );
    radGrad.addColorStop(0, 'rgba(0,0,0,0)');
    radGrad.addColorStop(0.65, `rgba(0,0,0,${(totalVignette / 100) * 0.22})`);
    radGrad.addColorStop(1, `rgba(0,0,0,${(totalVignette / 100) * 0.78})`);
    ctx.fillStyle = radGrad;
    ctx.fillRect(0, 0, targetWidth, targetHeight);
    ctx.restore();
  }

  // 7. Authentic ISO + Film Stock Organic Silver Halide Grain
  const isoGrainBoost = Math.max(0, Math.log2(exposure.iso / 100) * 7);
  const totalGrain = Math.min(100, film.grain + isoGrainBoost);
  if (totalGrain > 3) {
    ctx.save();
    ctx.globalCompositeOperation = 'overlay';
    const alpha = (totalGrain / 100) * 0.18;
    // Fast procedural grain speckle
    const step = 4;
    for (let y = 0; y < targetHeight; y += step * 3) {
      for (let x = 0; x < targetWidth; x += step * 3) {
        if (Math.random() > 0.62) {
          const v = Math.random() > 0.5 ? 255 : 0;
          ctx.fillStyle = `rgba(${v},${v},${v},${alpha})`;
          ctx.fillRect(
            x + Math.floor(Math.random() * 6),
            y + Math.floor(Math.random() * 6),
            2,
            2
          );
        }
      }
    }
    ctx.restore();
  }

  // 8. Quartz Analog Date Stamp ('26 09 26)
  if (assist.dateStamp) {
    ctx.save();
    const fontSize = Math.max(14, Math.round(targetWidth * 0.022));
    ctx.font = `600 ${fontSize}px "JetBrains Mono", monospace`;
    ctx.fillStyle = 'rgba(255, 132, 24, 0.92)';
    ctx.shadowColor = 'rgba(235, 65, 0, 0.75)';
    ctx.shadowBlur = 6;
    ctx.textAlign = 'right';
    ctx.fillText("'26 09 26", targetWidth - targetWidth * 0.04, targetHeight - targetHeight * 0.045);
    ctx.restore();
  }

  // 9. Optional Viewfinder Diagnostic Overlays (Zebra Stripes & Focus Peaking)
  if (includeOverlaysInRender && (assist.zebraStripes || assist.focusPeaking)) {
    const imgData = ctx.getImageData(0, 0, targetWidth, targetHeight);
    const data = imgData.data;
    const stride = 2;

    for (let y = 1; y < targetHeight - 1; y += stride) {
      for (let x = 1; x < targetWidth - 1; x += stride) {
        const idx = (y * targetWidth + x) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];
        const luma = 0.299 * r + 0.587 * g + 0.114 * b;

        // Zebra 95% IRE Overexposure Diagonal Stripes
        if (assist.zebraStripes && luma > 242) {
          if ((x + y) % 10 < 4) {
            data[idx] = 242;
            data[idx + 1] = 183;
            data[idx + 2] = 5;
          }
        }

        // Focus Peaking (High-frequency horizontal/vertical edge gradient)
        if (assist.focusPeaking && blurPx < 2.2) {
          const rightIdx = (y * targetWidth + (x + 1)) * 4;
          const downIdx = ((y + 1) * targetWidth + x) * 4;
          const edgeDelta =
            Math.abs(r - data[rightIdx]) +
            Math.abs(g - data[rightIdx + 1]) +
            Math.abs(g - data[downIdx + 1]);
          if (edgeDelta > 95) {
            data[idx] = 16;
            data[idx + 1] = 245;
            data[idx + 2] = 150;
          }
        }
      }
    }
    ctx.putImageData(imgData, 0, 0);
  }

  ctx.restore();
}

// Render Darkroom Non-Destructive Graded Image with optional Gallery Frame
export async function renderDarkroomExport(
  sourceDataUrl: string,
  adjustments: DarkroomAdjustments,
  film: FilmStockProfile,
  dateStampText: string
): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const baseW = img.naturalWidth || 1280;
      const baseH = img.naturalHeight || 720;

      // Determine border padding for frame style
      let padTop = 0;
      let padBottom = 0;
      let padSide = 0;

      if (adjustments.frameStyle === 'museum') {
        padSide = Math.round(baseW * 0.06);
        padTop = Math.round(baseW * 0.06);
        padBottom = Math.round(baseW * 0.085);
      } else if (adjustments.frameStyle === 'instant') {
        padSide = Math.round(baseW * 0.045);
        padTop = Math.round(baseW * 0.045);
        padBottom = Math.round(baseW * 0.15);
      } else if (adjustments.frameStyle === 'film35') {
        padSide = Math.round(baseW * 0.03);
        padTop = Math.round(baseH * 0.085);
        padBottom = Math.round(baseH * 0.085);
      }

      canvas.width = baseW + padSide * 2;
      canvas.height = baseH + padTop + padBottom;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(sourceDataUrl);
        return;
      }

      // Draw frame background if enabled
      if (adjustments.frameStyle === 'museum' || adjustments.frameStyle === 'instant') {
        ctx.fillStyle = '#F4F4F0';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else if (adjustments.frameStyle === 'film35') {
        ctx.fillStyle = '#09090B';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw 35mm sprocket holes along top and bottom borders
        ctx.fillStyle = '#18181B';
        const holeW = Math.round(baseW * 0.024);
        const holeH = Math.round(padTop * 0.46);
        const step = Math.round(baseW * 0.055);
        for (let x = padSide; x < canvas.width - padSide - holeW; x += step) {
          ctx.beginPath();
          ctx.roundRect(x, Math.round(padTop * 0.26), holeW, holeH, 4);
          ctx.roundRect(x, canvas.height - padBottom + Math.round(padBottom * 0.26), holeW, holeH, 4);
          ctx.fill();
        }

        // Film rebate edge markings
        ctx.fillStyle = 'rgba(242, 183, 5, 0.68)';
        ctx.font = `500 ${Math.max(11, Math.round(baseW * 0.011))}px "JetBrains Mono", monospace`;
        ctx.fillText(`VESPERA ${film.code} · SAFETY FILM`, padSide, Math.round(padTop * 0.18));
        ctx.fillText('24A  ·  35MM OPTICAL', canvas.width - padSide - 190, canvas.height - Math.round(padBottom * 0.1));
      }

      // Create inner image canvas
      const innerCanvas = document.createElement('canvas');
      innerCanvas.width = baseW;
      innerCanvas.height = baseH;
      const innerCtx = innerCanvas.getContext('2d');

      if (innerCtx) {
        const brightnessPct = Math.max(30, Math.min(220, Math.round(100 * Math.pow(2, adjustments.exposure * 0.5))));
        const contrastPct = Math.max(40, Math.min(190, 100 + adjustments.contrast));
        const saturatePct = Math.max(0, Math.min(220, adjustments.saturation));

        innerCtx.filter = `brightness(${brightnessPct}%) contrast(${contrastPct}%) saturate(${saturatePct}%)`;
        innerCtx.drawImage(img, 0, 0, baseW, baseH);
        innerCtx.filter = 'none';

        // Warmth
        if (Math.abs(adjustments.warmth) > 1) {
          innerCtx.save();
          innerCtx.globalCompositeOperation = 'soft-light';
          if (adjustments.warmth > 0) {
            innerCtx.fillStyle = `rgba(255, 165, 48, ${Math.min(0.4, Math.abs(adjustments.warmth) * 0.0065)})`;
          } else {
            innerCtx.fillStyle = `rgba(56, 152, 255, ${Math.min(0.4, Math.abs(adjustments.warmth) * 0.0065)})`;
          }
          innerCtx.fillRect(0, 0, baseW, baseH);
          innerCtx.restore();
        }

        // Fade
        if (adjustments.fade > 0) {
          innerCtx.save();
          innerCtx.globalCompositeOperation = 'screen';
          innerCtx.fillStyle = `rgba(30, 28, 34, ${(adjustments.fade / 100) * 0.22})`;
          innerCtx.fillRect(0, 0, baseW, baseH);
          innerCtx.restore();
        }

        // Vignette
        if (adjustments.vignette > 0) {
          innerCtx.save();
          const radGrad = innerCtx.createRadialGradient(
            baseW / 2,
            baseH / 2,
            Math.min(baseW, baseH) * 0.28,
            baseW / 2,
            baseH / 2,
            Math.max(baseW, baseH) * 0.72
          );
          radGrad.addColorStop(0, 'rgba(0,0,0,0)');
          radGrad.addColorStop(1, `rgba(0,0,0,${(adjustments.vignette / 100) * 0.78})`);
          innerCtx.fillStyle = radGrad;
          innerCtx.fillRect(0, 0, baseW, baseH);
          innerCtx.restore();
        }

        // Grain
        if (adjustments.grain > 2) {
          innerCtx.save();
          innerCtx.globalCompositeOperation = 'overlay';
          const alpha = (adjustments.grain / 100) * 0.18;
          for (let y = 0; y < baseH; y += 10) {
            for (let x = 0; x < baseW; x += 10) {
              if (Math.random() > 0.6) {
                const v = Math.random() > 0.5 ? 255 : 0;
                innerCtx.fillStyle = `rgba(${v},${v},${v},${alpha})`;
                innerCtx.fillRect(x + (Math.random() * 5), y + (Math.random() * 5), 2, 2);
              }
            }
          }
          innerCtx.restore();
        }

        // Date Stamp
        if (adjustments.dateStamp) {
          innerCtx.save();
          const fontSize = Math.max(15, Math.round(baseW * 0.022));
          innerCtx.font = `600 ${fontSize}px "JetBrains Mono", monospace`;
          innerCtx.fillStyle = 'rgba(255, 132, 24, 0.92)';
          innerCtx.shadowColor = 'rgba(235, 65, 0, 0.75)';
          innerCtx.shadowBlur = 6;
          innerCtx.textAlign = 'right';
          innerCtx.fillText(dateStampText || "'26 09 26", baseW - baseW * 0.04, baseH - baseH * 0.045);
          innerCtx.restore();
        }

        ctx.drawImage(innerCanvas, padSide, padTop);

        // Museum / Instant caption signature
        if (adjustments.frameStyle === 'museum' || adjustments.frameStyle === 'instant') {
          ctx.fillStyle = '#27272A';
          ctx.font = `500 ${Math.max(12, Math.round(baseW * 0.013))}px "JetBrains Mono", monospace`;
          ctx.textAlign = 'between';
          ctx.fillText(
            `VESPERA OPTICS  ·  ${film.name.toUpperCase()}`,
            padSide,
            baseH + padTop + Math.round(padBottom * 0.58)
          );
        }
      }

      resolve(canvas.toDataURL('image/jpeg', 0.94));
    };
    img.onerror = () => resolve(sourceDataUrl);
    img.src = sourceDataUrl;
  });
}

// Convert DataURL to Blob for reliable mobile & desktop downloads
export function dataUrlToBlob(dataUrl: string): Blob {
  const parts = dataUrl.split(',');
  const mimeMatch = parts[0].match(/:(.*?);/);
  const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
  const bstr = atob(parts[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
}

// Immediately download photo to Phone or PC storage
export function triggerDirectDownload(dataUrl: string, filename: string) {
  try {
    const blob = dataUrlToBlob(dataUrl);
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 4000);
  } catch {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

// Native mobile share sheet (Save to Photos on iOS/Android) with fallback to direct download
export async function shareOrDownloadPhoto(dataUrl: string, filename: string, title = 'Vespera Optics Photo') {
  try {
    const blob = dataUrlToBlob(dataUrl);
    const file = new File([blob], filename, { type: blob.type || 'image/jpeg' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({
        files: [file],
        title,
        text: 'Captured with Vespera Optics',
      });
      return;
    }
  } catch {
    // Fallback to direct download if user cancels or browser doesn't support file share
  }
  triggerDirectDownload(dataUrl, filename);
}

